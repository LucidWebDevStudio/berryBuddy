"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getChuckNorrisJokeController = void 0;
const getChuckNorrisJokeController = async (req, res) => {
    const response = await fetch("https://api.chucknorris.io/jokes/random");
    console.log("Fetch response");
    console.log(response);
    const data = await response.json();
    console.log("Parsed json data");
    console.log(data);
    res.json({ joke: data.value });
};
exports.getChuckNorrisJokeController = getChuckNorrisJokeController;
