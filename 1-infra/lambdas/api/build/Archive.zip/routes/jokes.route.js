"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jokesRouter = void 0;
const express_1 = require("express");
const get_chuck_norris_joke_controller_1 = require("../controllers/get-chuck-norris-joke.controller");
exports.jokesRouter = (0, express_1.Router)();
exports.jokesRouter.get("/", get_chuck_norris_joke_controller_1.getChuckNorrisJokeController);
