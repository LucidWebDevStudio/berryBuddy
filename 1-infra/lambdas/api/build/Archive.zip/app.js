"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const jokes_route_1 = require("./routes/jokes.route");
exports.app = (0, express_1.default)();
exports.app.use(jokes_route_1.jokesRouter);
exports.app.listen(3000, () => console.log("Web server is working and listening to port 3000!"));
